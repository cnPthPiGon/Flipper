# Hardware notes (summary)
- ESP32 (any common devboard) for Wi-Fi and GPIO.
- IR LED (with resistor) for TX; TSOP receiver for RX.
- MFRC522 (SPI) module for simple NFC tag reads (only UID in this demo).
- Use level shifting and proper drivers for any high-power loads.
- For solenoids/relays, always use MOSFET drivers and separate power supplies.