# Legal & Safety (important)
UTILISEZ CE PROJET UNIQUEMENT SUR VOS APPAREILS OU AVEC AUTORISATION EXPLICITE.
Ne tentez pas de lire, cloner ou reproduire des badges d'accès ou des signaux
propriétaires sans permission. Respectez les lois locales.

Ce dépôt est pédagogique : il montre comment construire des endpoints HTTP
pour interagir avec du hardware. Il ne fournit pas d'outils d'exploitation.