const ESP = "http://192.168.4.1";
function info(){ fetch(ESP + "/").then(r=>r.text()).then(t=>out(t)).catch(e=>out(e)); }
function irRecv(){ fetch(ESP + "/ir/recv").then(r=>r.text()).then(t=>out(t)).catch(e=>out(e)); }
function nfcRead(){ fetch(ESP + "/nfc/read").then(r=>r.text()).then(t=>out(t)).catch(e=>out(e)); }
function out(t){ document.getElementById('out').innerText = typeof t === 'string' ? t : JSON.stringify(t, null, 2); }