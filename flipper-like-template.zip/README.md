# Flipper-like Template
Projet pédagogique pour expérimenter des interfaces IR / NFC / Web avec un ESP32,
un client Termux et une interface web. **Utiliser uniquement sur votre matériel
ou avec autorisation explicite.**

Structure:
- firmware/esp32/main.ino : firmware ESP32 (IR recv/send demo + MFRC522 read)
- termux-client/client.py   : client Python pour Termux (HTTP requests)
- termux-client/requirements.txt
- web-ui/index.html
- web-ui/js/app.js
- docs/hardware.md
- docs/legal.md
- LICENSE (MIT)