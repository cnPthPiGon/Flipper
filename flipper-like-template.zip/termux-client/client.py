#!/usr/bin/env python3
# client.py - Termux controller for ESP32 flipper-like (educational/demo use)
import requests, sys

ESP_IP = "192.168.4.1"  # default AP IP for ESP32 when in softAP mode
BASE = f"http://{ESP_IP}"

def info():
    r = requests.get(BASE + "/", timeout=3)
    print(r.text)

def ir_recv():
    r = requests.get(BASE + "/ir/recv", timeout=3)
    print(r.status_code, r.text)

def ir_send(raw):
    r = requests.get(BASE + "/ir/send", params={"raw": raw}, timeout=3)
    print(r.status_code, r.text)

def nfc_read():
    r = requests.get(BASE + "/nfc/read", timeout=3)
    print(r.status_code, r.text)

def usage():
    print("Usage: client.py info | ir_recv | ir_send <raw> | nfc_read")
    sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        usage()
    cmd = sys.argv[1]
    if cmd == "info":
        info()
    elif cmd == "ir_recv":
        ir_recv()
    elif cmd == "ir_send" and len(sys.argv) == 3:
        ir_send(sys.argv[2])
    elif cmd == "nfc_read":
        nfc_read()
    else:
        usage()